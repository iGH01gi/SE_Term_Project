import UI.MainFrame;

public class Main {
    public static void main(String[] args) {
        MainFrame mf=new MainFrame();
    }
}
