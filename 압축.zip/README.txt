-BridgeGame폴더: 자바 프로젝트 폴더. 소스 코드 및 리소스, class파일등이 모두 들어 있음.
(Main.class파일은 SE_Term_Project\BridgeGame\out\production\BridgeGame경로에 있음.)

-diagram폴더: 설계하는데 사용한 모든 다이어그램이 png형태로 들어 있음. 레포트에서 모두 사용됨.

-Operation Contracts폴더: 설계할때 사용한 operation contracts.pdf가 들어 있음.

-use-case명세 폴더: use-case명세 pdf파일들이 들어 있음. 

-레포트(20182345이건호): 해당 프로젝트에 대한 레포트. 모든 내용이 들어 있음. 

-프로젝트설명영상: 해당 프로그램 시현 및 설계등에 대한 설명을 담은 비디오 클립.